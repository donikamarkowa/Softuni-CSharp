﻿namespace Footballers.DataProcessor
{
    using Data;
    using Footballers.Data.Models.Enums;
    using Newtonsoft.Json;
    using System.Globalization;

    public class Serializer
    {
        public static string ExportCoachesWithTheirFootballers(FootballersContext context)
        {
            throw new NotImplementedException();
        }

        public static string ExportTeamsWithMostFootballers(FootballersContext context, DateTime date)
        {
            throw new NotImplementedException();
        }
    }
}
