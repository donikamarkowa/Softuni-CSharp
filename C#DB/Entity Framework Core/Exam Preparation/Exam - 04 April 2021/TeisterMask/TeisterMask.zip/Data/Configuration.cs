﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-CTSCET9\SQLEXPRESS01;Database=TeisterMaskExam;Integrated Security = True;TrustServerCertificate=True;";
    }
}
