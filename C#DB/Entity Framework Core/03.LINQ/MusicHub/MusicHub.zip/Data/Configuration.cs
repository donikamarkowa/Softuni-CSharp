﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
             @"Server=DESKTOP-CTSCET9\SQLEXPRESS01;Database=MusicHub;Integrated Security = True;TrustServerCertificate=True;";
    }
}
