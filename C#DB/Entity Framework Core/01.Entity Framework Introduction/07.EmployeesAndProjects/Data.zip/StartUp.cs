﻿namespace SoftUni
{
    using SoftUni.Data;
    using System.Reflection;
    using System.Text;

    public class StartUp
    {
        static void Main(string[] args)
        {
            using SoftUniContext context = new SoftUniContext();

            string result = GetEmployeesInPeriod(context);

            Console.WriteLine(result);
        }

        public static string GetEmployeesInPeriod(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employeesWithProjects = context
                .Employees
                .Where(e => e.Projects.Any(ep => ep.StartDate.Year >= 2001 && ep.StartDate.Year <= 2003))
                .Take(10)
                .Select(e => new
                {
                    e.FirstName,
                    e.LastName,
                    ManagerFirstName = e.Manager.FirstName,
                    ManagerLastName = e.Manager.LastName,
                    Projects = e.Projects.Select(p => new
                    {
                        ProjectName = p.Name,
                        ProjectStartDate = p.StartDate.ToString("M/d/yyyy h:mm:ss tt"),
                        ProjectEndDate = p.EndDate.HasValue
                        ? p.EndDate.Value.ToString("M/d/yyyy h:mm:ss tt")
                        : "not finished"
                    }).ToList()
                })
                .ToList();

            foreach (var e in employeesWithProjects)
            {
                sb.AppendLine($"{e.FirstName} {e.LastName} - Manager: {e.ManagerFirstName} {e.ManagerLastName}");
                foreach (var p in e.Projects)
                {
                    sb.AppendLine($"--{p.ProjectName} - {p.ProjectStartDate} - {p.ProjectEndDate}");
                }
            }

            return sb.ToString().TrimEnd();
        }
    }
}