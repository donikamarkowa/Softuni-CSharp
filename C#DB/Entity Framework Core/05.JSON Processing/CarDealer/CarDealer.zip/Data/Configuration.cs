﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-CTSCET9\SQLEXPRESS01;Database=CarDealer;Integrated Security=True;TrustServerCertificate=True;";
    }
}
