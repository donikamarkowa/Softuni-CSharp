﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-CTSCET9\SQLEXPRESS01;Database=ProductShop;Integrated Security = True;TrustServerCertificate=True;";
    }
}
